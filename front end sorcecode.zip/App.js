import * as React from 'react';
import MainContainer from './navigation/MainContainer';

function App() {
  
  return (
    
    <MainContainer/>
  );
}

export default App;